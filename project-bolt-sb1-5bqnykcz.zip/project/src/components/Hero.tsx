import React from 'react';
import { ArrowRight } from 'lucide-react';

const Hero = () => {
  return (
    <section id="inicio" className="pt-16 bg-gradient-to-br from-[#1D3557] to-[#2A9D8F] text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center py-20">
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-5xl lg:text-6xl font-bold leading-tight">
                Lorena Fries
                <span className="block text-[#E9C46A]">Monleón</span>
              </h1>
              <p className="text-xl text-gray-200">
                Diputada por el Distrito 10
              </p>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-6 border border-white/20">
              <p className="text-lg leading-relaxed">
                Comprometida con los derechos humanos, la equidad de género y la justicia social. 
                Trabajando por una sociedad más justa e inclusiva para todas y todos.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <a
                href="#quien-soy"
                className="inline-flex items-center justify-center px-8 py-3 bg-[#E9C46A] text-[#1D3557] font-semibold rounded-full hover:bg-[#E9C46A]/90 transition-colors duration-200 group"
              >
                Conoce mi trabajo
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </a>
              <a
                href="#contacto"
                className="inline-flex items-center justify-center px-8 py-3 border-2 border-white text-white font-semibold rounded-full hover:bg-white hover:text-[#1D3557] transition-colors duration-200"
              >
                Contáctame
              </a>
            </div>
          </div>

          <div className="relative">
            <div className="aspect-square rounded-2xl bg-gradient-to-br from-[#E9C46A]/20 to-[#2A9D8F]/20 backdrop-blur-sm border border-white/20 flex items-center justify-center">
              <img
                src="https://images.pexels.com/photos/2381069/pexels-photo-2381069.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Lorena Fries Monleón"
                className="w-4/5 h-4/5 object-cover rounded-xl shadow-2xl"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;