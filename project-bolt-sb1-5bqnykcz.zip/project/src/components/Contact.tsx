import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send, Instagram, Twitter, MessageCircle } from 'lucide-react';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission here
    console.log('Form submitted:', formData);
  };

  const socialLinks = [
    {
      name: 'Instagram',
      icon: <Instagram className="h-6 w-6" />,
      url: '#',
      color: 'hover:bg-pink-500'
    },
    {
      name: 'X (Twitter)',
      icon: <Twitter className="h-6 w-6" />,
      url: '#',
      color: 'hover:bg-black'
    },
    {
      name: 'TikTok',
      icon: <MessageCircle className="h-6 w-6" />,
      url: '#',
      color: 'hover:bg-black'
    },
    {
      name: 'Facebook',
      icon: <MessageCircle className="h-6 w-6" />,
      url: '#',
      color: 'hover:bg-blue-600'
    }
  ];

  const contactInfo = [
    {
      icon: <Mail className="h-6 w-6" />,
      title: "Correo Electrónico",
      detail: "lfries@congreso.cl",
      link: "mailto:lfries@congreso.cl"
    },
    {
      icon: <Phone className="h-6 w-6" />,
      title: "Teléfono Oficina",
      detail: "+56 32 250 5000",
      link: "tel:+56322505000"
    },
    {
      icon: <MapPin className="h-6 w-6" />,
      title: "Oficina Congreso",
      detail: "Valparaíso, Chile",
      link: "#"
    }
  ];

  return (
    <section id="contacto" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-6 mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-[#1D3557]">
            Contacto
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Tu voz es importante. Escríbeme para compartir tus inquietudes, 
            propuestas o para conocer más sobre mi trabajo legislativo.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16">
          {/* Contact Form */}
          <div className="bg-gray-50 p-8 rounded-2xl">
            <h3 className="text-2xl font-bold text-[#1D3557] mb-6">
              Envíame un mensaje
            </h3>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-[#1D3557] mb-2">
                    Nombre completo *
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    required
                    value={formData.name}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#2A9D8F] focus:border-transparent transition-colors"
                    placeholder="Tu nombre completo"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-[#1D3557] mb-2">
                    Correo electrónico *
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    required
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#2A9D8F] focus:border-transparent transition-colors"
                    placeholder="tu@email.com"
                  />
                </div>
              </div>
              
              <div>
                <label htmlFor="subject" className="block text-sm font-medium text-[#1D3557] mb-2">
                  Tema *
                </label>
                <select
                  id="subject"
                  name="subject"
                  required
                  value={formData.subject}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#2A9D8F] focus:border-transparent transition-colors"
                >
                  <option value="">Selecciona un tema</option>
                  <option value="legislativo">Trabajo Legislativo</option>
                  <option value="derechos-humanos">Derechos Humanos</option>
                  <option value="genero">Equidad de Género</option>
                  <option value="distrito">Asuntos del Distrito 10</option>
                  <option value="otro">Otro tema</option>
                </select>
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-medium text-[#1D3557] mb-2">
                  Mensaje *
                </label>
                <textarea
                  id="message"
                  name="message"
                  required
                  rows={6}
                  value={formData.message}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#2A9D8F] focus:border-transparent transition-colors resize-none"
                  placeholder="Escribe tu mensaje aquí..."
                />
              </div>

              <button
                type="submit"
                className="w-full bg-[#2A9D8F] text-white font-semibold py-3 px-6 rounded-lg hover:bg-[#2A9D8F]/90 transition-colors duration-200 flex items-center justify-center"
              >
                <Send className="mr-2 h-5 w-5" />
                Enviar mensaje
              </button>
            </form>
          </div>

          {/* Contact Information */}
          <div className="space-y-8">
            <div>
              <h3 className="text-2xl font-bold text-[#1D3557] mb-6">
                Información de contacto
              </h3>
              <div className="space-y-4">
                {contactInfo.map((info, index) => (
                  <a
                    key={index}
                    href={info.link}
                    className="flex items-center p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors duration-200 group"
                  >
                    <div className="flex items-center justify-center w-12 h-12 bg-[#2A9D8F]/10 text-[#2A9D8F] rounded-full mr-4 group-hover:bg-[#2A9D8F] group-hover:text-white transition-colors duration-200">
                      {info.icon}
                    </div>
                    <div>
                      <h4 className="font-semibold text-[#1D3557]">
                        {info.title}
                      </h4>
                      <p className="text-gray-600">
                        {info.detail}
                      </p>
                    </div>
                  </a>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-2xl font-bold text-[#1D3557] mb-6">
                Sígueme en redes sociales
              </h3>
              <div className="flex space-x-4">
                {socialLinks.map((social, index) => (
                  <a
                    key={index}
                    href={social.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`flex items-center justify-center w-12 h-12 bg-gray-200 text-gray-600 rounded-full hover:text-white transition-colors duration-200 ${social.color}`}
                    title={social.name}
                  >
                    {social.icon}
                  </a>
                ))}
              </div>
            </div>

            <div className="bg-[#2A9D8F]/5 p-6 rounded-lg">
              <h4 className="font-bold text-[#1D3557] mb-2">
                Horarios de atención ciudadana
              </h4>
              <p className="text-gray-600 text-sm">
                Lunes a Viernes: 9:00 - 17:00 hrs<br />
                Para casos urgentes, contáctame a través de mis redes sociales.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;