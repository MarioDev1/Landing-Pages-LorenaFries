import React from 'react';
import { ExternalLink, Play, Image, Calendar } from 'lucide-react';

const News = () => {
  const newsItems = [
    {
      type: 'video',
      title: 'Soy Representante - Entrevista sobre Derechos Humanos',
      description: 'Conversación sobre los desafíos actuales en materia de derechos humanos y el trabajo legislativo.',
      date: '2024-01-15',
      image: 'https://images.pexels.com/photos/3760067/pexels-photo-3760067.jpeg?auto=compress&cs=tinysrgb&w=800',
      link: '#'
    },
    {
      type: 'interview',
      title: 'Radio ADN - Proyecto contra el Reclutamiento de Menores',
      description: 'Análisis del proyecto de ley para prevenir el reclutamiento de menores por el crimen organizado.',
      date: '2023-12-20',
      image: 'https://images.pexels.com/photos/4348401/pexels-photo-4348401.jpeg?auto=compress&cs=tinysrgb&w=800',
      link: '#'
    },
    {
      type: 'article',
      title: 'La Tercera - Reformas para la Equidad de Género',
      description: 'Columna sobre la importancia de las reformas legislativas para avanzar en equidad de género.',
      date: '2023-12-10',
      image: 'https://images.pexels.com/photos/3184295/pexels-photo-3184295.jpeg?auto=compress&cs=tinysrgb&w=800',
      link: '#'
    },
    {
      type: 'activity',
      title: 'Visita a Terreno - Distrito 10',
      description: 'Recorrido por comunas del distrito, escuchando las necesidades de vecinas y vecinos.',
      date: '2023-11-25',
      image: 'https://images.pexels.com/photos/3184432/pexels-photo-3184432.jpeg?auto=compress&cs=tinysrgb&w=800',
      link: '#'
    }
  ];

  const getIcon = (type: string) => {
    switch (type) {
      case 'video':
        return <Play className="h-5 w-5" />;
      case 'interview':
        return <ExternalLink className="h-5 w-5" />;
      case 'article':
        return <ExternalLink className="h-5 w-5" />;
      default:
        return <Image className="h-5 w-5" />;
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'video':
        return 'Video';
      case 'interview':
        return 'Entrevista';
      case 'article':
        return 'Artículo';
      default:
        return 'Actividad';
    }
  };

  return (
    <section id="noticias" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-6 mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-[#1D3557]">
            Noticias y Multimedia
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Mantente informado sobre mi trabajo legislativo, entrevistas, 
            publicaciones en prensa y actividades en terreno.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {newsItems.map((item, index) => (
            <article
              key={index}
              className="bg-white rounded-2xl shadow-lg hover:shadow-xl transition-shadow duration-300 overflow-hidden"
            >
              <div className="aspect-video relative overflow-hidden">
                <img
                  src={item.image}
                  alt={item.title}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
                <div className="absolute top-4 left-4">
                  <span className="inline-flex items-center px-3 py-1 bg-[#E9C46A] text-[#1D3557] rounded-full text-sm font-medium">
                    {getIcon(item.type)}
                    <span className="ml-2">{getTypeLabel(item.type)}</span>
                  </span>
                </div>
                <div className="absolute bottom-4 left-4 flex items-center text-white text-sm">
                  <Calendar className="h-4 w-4 mr-2" />
                  {new Date(item.date).toLocaleDateString('es-CL', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric'
                  })}
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-[#1D3557] mb-3 line-clamp-2">
                  {item.title}
                </h3>
                <p className="text-gray-600 leading-relaxed mb-4">
                  {item.description}
                </p>
                <a
                  href={item.link}
                  className="inline-flex items-center text-[#2A9D8F] font-semibold hover:text-[#2A9D8F]/80 transition-colors duration-200"
                >
                  Ver más
                  <ExternalLink className="ml-2 h-4 w-4" />
                </a>
              </div>
            </article>
          ))}
        </div>

        <div className="text-center">
          <a
            href="#"
            className="inline-flex items-center px-8 py-3 bg-[#2A9D8F] text-white font-semibold rounded-full hover:bg-[#2A9D8F]/90 transition-colors duration-200"
          >
            <Image className="mr-2 h-5 w-5" />
            Ver galería completa
          </a>
        </div>
      </div>
    </section>
  );
};

export default News;