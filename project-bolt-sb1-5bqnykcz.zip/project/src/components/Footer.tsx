import React from 'react';
import { Heart, Instagram, Twitter, MessageCircle, Mail } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const socialLinks = [
    {
      name: 'Instagram',
      icon: <Instagram className="h-5 w-5" />,
      url: '#'
    },
    {
      name: 'X (Twitter)',
      icon: <Twitter className="h-5 w-5" />,
      url: '#'
    },
    {
      name: 'TikTok',
      icon: <MessageCircle className="h-5 w-5" />,
      url: '#'
    },
    {
      name: 'Facebook',
      icon: <MessageCircle className="h-5 w-5" />,
      url: '#'
    }
  ];

  const footerLinks = [
    {
      title: 'Navegación',
      links: [
        { name: 'Inicio', href: '#inicio' },
        { name: 'Quién Soy', href: '#quien-soy' },
        { name: 'Trayectoria', href: '#trayectoria' },
        { name: 'Trabajo Legislativo', href: '#trabajo-legislativo' }
      ]
    },
    {
      title: 'Recursos',
      links: [
        { name: 'Noticias', href: '#noticias' },
        { name: 'Publicaciones', href: '#publicaciones' },
        { name: 'Contacto', href: '#contacto' },
        { name: 'Cámara de Diputados', href: 'https://www.camara.cl' }
      ]
    },
    {
      title: 'Legal',
      links: [
        { name: 'Política de Privacidad', href: '#' },
        { name: 'Términos de Uso', href: '#' },
        { name: 'Transparencia', href: '#' },
        { name: 'Accesibilidad', href: '#' }
      ]
    }
  ];

  return (
    <footer className="bg-[#1D3557] text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="py-16">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Brand Section */}
            <div className="lg:col-span-1">
              <h3 className="text-2xl font-bold mb-4">
                Lorena Fries Monleón
              </h3>
              <p className="text-[#2A9D8F] font-semibold mb-4">
                Diputada por el Distrito 10
              </p>
              <p className="text-gray-300 leading-relaxed mb-6">
                Comprometida con los derechos humanos, la equidad de género y la justicia social. 
                Construyendo una sociedad más justa e inclusiva.
              </p>
              
              <div className="flex space-x-4">
                {socialLinks.map((social, index) => (
                  <a
                    key={index}
                    href={social.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center w-10 h-10 bg-white/10 hover:bg-[#2A9D8F] text-white rounded-full transition-colors duration-200"
                    title={social.name}
                  >
                    {social.icon}
                  </a>
                ))}
              </div>
            </div>

            {/* Links Sections */}
            {footerLinks.map((section, index) => (
              <div key={index}>
                <h4 className="text-lg font-semibold mb-4">
                  {section.title}
                </h4>
                <ul className="space-y-3">
                  {section.links.map((link, linkIndex) => (
                    <li key={linkIndex}>
                      <a
                        href={link.href}
                        className="text-gray-300 hover:text-[#E9C46A] transition-colors duration-200"
                      >
                        {link.name}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-white/10 py-8">
          <div className="flex flex-col md:flex-row items-center justify-between space-y-4 md:space-y-0">
            <div className="text-center md:text-left">
              <p className="text-gray-300">
                © {currentYear} Lorena Fries Monleón. Todos los derechos reservados.
              </p>
              <p className="text-sm text-gray-400 mt-1">
                Página oficial de la Diputada por el Distrito 10
              </p>
            </div>

            <div className="flex items-center space-x-2 text-gray-300">
              <span>Hecho con</span>
              <Heart className="h-4 w-4 text-[#E9C46A]" />
              <span>para la ciudadanía</span>
            </div>
          </div>
        </div>

        {/* Emergency Contact */}
        <div className="border-t border-white/10 py-6">
          <div className="bg-[#2A9D8F]/10 rounded-lg p-4">
            <div className="flex items-center justify-center space-x-2">
              <Mail className="h-5 w-5 text-[#2A9D8F]" />
              <span className="text-sm text-gray-300">
                Para casos urgentes: 
                <a 
                  href="mailto:lfries@congreso.cl" 
                  className="text-[#E9C46A] hover:text-[#E9C46A]/80 transition-colors ml-1"
                >
                  lfries@congreso.cl
                </a>
              </span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;