import React from 'react';
import { GraduationCap, Heart, Users, Scale } from 'lucide-react';

const About = () => {
  const highlights = [
    {
      icon: <GraduationCap className="h-8 w-8" />,
      title: "Formación Académica",
      description: "Licenciada en Derecho, Universidad de Salamanca. Magíster en Oxford University."
    },
    {
      icon: <Heart className="h-8 w-8" />,
      title: "Derechos Humanos",
      description: "Más de 20 años de experiencia defendiendo los derechos fundamentales y la dignidad humana."
    },
    {
      icon: <Users className="h-8 w-8" />,
      title: "Equidad de Género",
      description: "Pionera en la promoción de políticas públicas para la igualdad de género y derechos de las mujeres."
    },
    {
      icon: <Scale className="h-8 w-8" />,
      title: "Justicia Social",
      description: "Comprometida con la construcción de una sociedad más justa e inclusiva para todas y todos."
    }
  ];

  return (
    <section id="quien-soy" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-6 mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-[#1D3557]">
            Quién Soy
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Una trayectoria dedicada a la defensa de los derechos humanos, 
            la equidad de género y la participación ciudadana.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16 items-center mb-16">
          <div className="space-y-6">
            <div className="prose prose-lg text-gray-700">
              <p className="text-lg leading-relaxed">
                Soy abogada, especialista en derechos humanos y feminista. Mi formación académica 
                incluye estudios en Derecho en la Universidad de Salamanca y un Magíster en 
                Oxford University, lo que me ha proporcionado una perspectiva internacional 
                sobre los derechos fundamentales y la justicia social.
              </p>
              <p className="text-lg leading-relaxed">
                Durante más de dos décadas, he trabajado incansablemente por la promoción y 
                protección de los derechos humanos en Chile, con especial énfasis en los 
                derechos de las mujeres, la participación ciudadana y la construcción de 
                una sociedad más equitativa e inclusiva.
              </p>
            </div>
          </div>
          
          <div className="relative">
            <div className="aspect-[4/5] rounded-2xl bg-gradient-to-br from-[#2A9D8F]/10 to-[#1D3557]/10 p-4">
              <img
                src="https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Lorena Fries en el Congreso"
                className="w-full h-full object-cover rounded-xl shadow-xl"
              />
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {highlights.map((item, index) => (
            <div
              key={index}
              className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow duration-300 text-center"
            >
              <div className="inline-flex items-center justify-center w-16 h-16 bg-[#2A9D8F]/10 text-[#2A9D8F] rounded-full mb-4">
                {item.icon}
              </div>
              <h3 className="text-xl font-bold text-[#1D3557] mb-3">
                {item.title}
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {item.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default About;