import React from 'react';
import { FileText, Users, Shield, Building2, Leaf, Gavel } from 'lucide-react';

const LegislativeWork = () => {
  const committees = [
    {
      name: "Comisión de Derechos Humanos",
      icon: <Shield className="h-6 w-6" />,
      description: "Fiscalización y promoción de políticas de derechos humanos"
    },
    {
      name: "Comisión de Seguridad Pública",
      icon: <Shield className="h-6 w-6" />,
      description: "Políticas de seguridad ciudadana y prevención del delito"
    },
    {
      name: "Comisión de Mujeres y Género",
      icon: <Users className="h-6 w-6" />,
      description: "Promoción de la igualdad de género y derechos de las mujeres"
    },
    {
      name: "Comisión de Constitución",
      icon: <Gavel className="h-6 w-6" />,
      description: "Reformas constitucionales y marco jurídico institucional"
    }
  ];

  const projects = [
    {
      title: "Prevención del Reclutamiento de Menores",
      category: "Seguridad Pública",
      description: "Proyecto para prevenir el reclutamiento de menores por parte del crimen organizado, fortaleciendo la protección de la infancia.",
      status: "En tramitación",
      icon: <Shield className="h-6 w-6" />
    },
    {
      title: "DD.HH. en Empresas",
      category: "Derechos Humanos",
      description: "Iniciativa para establecer estándares de derechos humanos en el sector empresarial y promover la responsabilidad social corporativa.",
      status: "En comisión",
      icon: <Building2 className="h-6 w-6" />
    },
    {
      title: "Reducción de Emisiones de Metano",
      category: "Medio Ambiente",
      description: "Proyecto para reducir las emisiones de metano y combatir el cambio climático desde una perspectiva de justicia ambiental.",
      status: "Aprobado en general",
      icon: <Leaf className="h-6 w-6" />
    },
    {
      title: "Reformas Municipales",
      category: "Institucionalidad",
      description: "Modernización de la gestión municipal para fortalecer la democracia local y la participación ciudadana.",
      status: "En tramitación",
      icon: <Gavel className="h-6 w-6" />
    }
  ];

  return (
    <section id="trabajo-legislativo" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-6 mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-[#1D3557]">
            Trabajo Legislativo
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Comprometida con la construcción de leyes que fortalezcan la democracia, 
            los derechos humanos y la justicia social.
          </p>
        </div>

        {/* Committees */}
        <div className="mb-20">
          <h3 className="text-2xl font-bold text-[#1D3557] mb-8 text-center">
            Comisiones en las que Participo
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {committees.map((committee, index) => (
              <div
                key={index}
                className="bg-white p-6 rounded-2xl shadow-lg hover:shadow-xl transition-shadow duration-300"
              >
                <div className="flex items-center justify-center w-12 h-12 bg-[#2A9D8F]/10 text-[#2A9D8F] rounded-full mb-4">
                  {committee.icon}
                </div>
                <h4 className="text-lg font-bold text-[#1D3557] mb-2">
                  {committee.name}
                </h4>
                <p className="text-gray-600 text-sm">
                  {committee.description}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Featured Projects */}
        <div>
          <h3 className="text-2xl font-bold text-[#1D3557] mb-8 text-center">
            Proyectos Destacados
          </h3>
          <div className="grid lg:grid-cols-2 gap-8">
            {projects.map((project, index) => (
              <div
                key={index}
                className="bg-white p-8 rounded-2xl shadow-lg hover:shadow-xl transition-shadow duration-300"
              >
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0">
                    <div className="flex items-center justify-center w-12 h-12 bg-[#2A9D8F]/10 text-[#2A9D8F] rounded-full">
                      {project.icon}
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <span className="px-3 py-1 bg-[#E9C46A]/20 text-[#1D3557] rounded-full text-xs font-medium">
                        {project.category}
                      </span>
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                        project.status === 'Aprobado en general' 
                          ? 'bg-green-100 text-green-800'
                          : 'bg-blue-100 text-blue-800'
                      }`}>
                        {project.status}
                      </span>
                    </div>
                    <h4 className="text-xl font-bold text-[#1D3557] mb-3">
                      {project.title}
                    </h4>
                    <p className="text-gray-600 leading-relaxed">
                      {project.description}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="text-center mt-12">
          <a
            href="https://www.camara.cl/diputados/detalle/fries-monleon-lorena"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center px-8 py-3 bg-[#1D3557] text-white font-semibold rounded-full hover:bg-[#1D3557]/90 transition-colors duration-200"
          >
            <FileText className="mr-2 h-5 w-5" />
            Ver más en Cámara de Diputados
          </a>
        </div>
      </div>
    </section>
  );
};

export default LegislativeWork;