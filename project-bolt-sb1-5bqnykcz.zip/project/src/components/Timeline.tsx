import React from 'react';
import { Calendar, Building, Users, Briefcase } from 'lucide-react';

const Timeline = () => {
  const timelineEvents = [
    {
      year: "2022-Presente",
      title: "Diputada de la República",
      organization: "Congreso Nacional",
      description: "Representando al Distrito 10, trabajando en las comisiones de Derechos Humanos, Seguridad, Mujeres y Género, y Constitución.",
      icon: <Building className="h-6 w-6" />,
      color: "bg-[#E9C46A]"
    },
    {
      year: "2016-2018",
      title: "Subsecretaria de DD.HH.",
      organization: "Ministerio de Justicia y DD.HH.",
      description: "Lideró políticas públicas en derechos humanos y memoria, promoviendo reformas estructurales en el sistema de justicia.",
      icon: <Briefcase className="h-6 w-6" />,
      color: "bg-[#2A9D8F]"
    },
    {
      year: "2010-2016",
      title: "Directora INDH",
      organization: "Instituto Nacional de Derechos Humanos",
      description: "Dirigió la consolidación del INDH como institución fiscalizadora independiente de los derechos humanos en Chile.",
      icon: <Users className="h-6 w-6" />,
      color: "bg-[#1D3557]"
    },
    {
      year: "2000-2022",
      title: "Presidenta",
      organization: "Corporación Humanas",
      description: "Lideró una de las organizaciones feministas más influyentes de Chile, promoviendo la igualdad de género y los derechos de las mujeres.",
      icon: <Calendar className="h-6 w-6" />,
      color: "bg-[#2A9D8F]"
    }
  ];

  return (
    <section id="trayectoria" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-6 mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-[#1D3557]">
            Mi Trayectoria
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Una carrera dedicada a la construcción de una sociedad más justa, 
            desde diferentes roles y responsabilidades.
          </p>
        </div>

        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-1/2 transform -translate-x-0.5 w-1 bg-gradient-to-b from-[#1D3557] to-[#2A9D8F] h-full"></div>

          <div className="space-y-12">
            {timelineEvents.map((event, index) => (
              <div
                key={index}
                className={`relative flex items-center ${
                  index % 2 === 0 ? 'justify-start' : 'justify-end'
                }`}
              >
                <div className={`w-full max-w-lg ${index % 2 === 0 ? 'pr-8' : 'pl-8'}`}>
                  <div className="bg-white p-8 rounded-2xl shadow-xl border border-gray-100 hover:shadow-2xl transition-shadow duration-300">
                    <div className="flex items-center space-x-4 mb-4">
                      <div className={`inline-flex items-center justify-center w-12 h-12 ${event.color} text-white rounded-full`}>
                        {event.icon}
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-[#1D3557]">
                          {event.title}
                        </h3>
                        <p className="text-[#2A9D8F] font-semibold">
                          {event.organization}
                        </p>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <span className="inline-block px-3 py-1 bg-[#E9C46A]/20 text-[#1D3557] rounded-full text-sm font-medium">
                        {event.year}
                      </span>
                      <p className="text-gray-600 leading-relaxed">
                        {event.description}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Timeline dot */}
                <div className="absolute left-1/2 transform -translate-x-1/2 w-4 h-4 bg-white border-4 border-[#2A9D8F] rounded-full z-10"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Timeline;