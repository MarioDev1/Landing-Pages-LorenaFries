import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/About';
import Timeline from './components/Timeline';
import LegislativeWork from './components/LegislativeWork';
import News from './components/News';
import Publications from './components/Publications';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <Hero />
      <About />
      <Timeline />
      <LegislativeWork />
      <News />
      <Publications />
      <Contact />
      <Footer />
    </div>
  );
}

export default App;